/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_main.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishafie <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/07 10:11:05 by ishafie           #+#    #+#             */
/*   Updated: 2015/12/19 22:39:59 by ishafie          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_fillit.h"
#include <string.h>
#include <stdlib.h>

int		main(int argc, char **argv)
{
	t_tetri	*t_t;
	char	tminos[MAX + 1];
	char	*map;
	int		len;
	int		nb_t;
	t_tetri	*save;

	if (argc == 2 && (ft_strcpy(tminos, ft_get_tetriminos(argv[1], &len, &nb_t))) != NULL)
	{
		if (!(t_t = (t_tetri*)malloc(sizeof(t_tetri) * nb_t)))
			return (0);
		if (!(save = (t_tetri*)malloc(sizeof(t_tetri) * nb_t)))
			return (0);
		map = create_map(&len, &t_t[0]);
		map = modify_map(map, nb_t);
		t_t = ft_conversion_tetriminos(tminos, map, t_t);
		int i = 1;
		while (i < 4)
		{
//			ft_putnbr(t_t[0].tc[i]);
			i++;
		}
		i = 1;
		int id = 0;
		int l_jump = 0;
		char c = 'A';
		while (id < nb_t)
		{
			while (i < 4)
			{
				if (t_t[id].tc[i] == 3)
				{
					if (t_t[id].tc[i - 1] != t_t[id].tc[i] - 1)//ft adjust
						t_t[id].tc[i] = t_t[id].tc[i] + ((len / 16 * 4 + 4) - 4);
				}
				else if ((l_jump = t_t[id].tc[i] / 4) >= 1)
				{
					t_t[id].tc[i] = (t_t[id].tc[i] % 4) + (len / 16 * 4 + 4) * l_jump; // a revoir au cas ou

					if ((((t_t[id].tc[i] + 1) % 4) == 0))
						t_t[id].tc[i] = t_t[id].tc[i] + ((len / 16 * 4 + 4) - 4);
				}
				i++;
			}
			t_t[id].letter = c++;
			i = 1;
			id++;
		}
		t_t[0].nb_t = nb_t;
		t_t[0].l = len / 16 * 4 + 4;
/*		while (id < nb_t)
		{

			while (i < 4)
			{
				ft_putnbr(t_t[id].tc[i]);
				i++;
			}
			ft_putchar('\n');
			i = 1;
			id++;
		}
		ft_putchar('\n');*/
		save = t_t;
		ft_putnbr(t_t[0].nb_t * 4);
		int nb_ext = ft_sqrt((t_t[0].nb_t * 4));
		i = 0;
		ft_putnbr(nb_ext);
		while (i++ < nb_ext)
			extend_map(map);
		if ((ft_add_to_map(map, t_t, 0, save)) == 0)
			ft_putstr("error");
		else
		{
			ft_putchar('\n');
			ft_putstr(map);
		}



//		ft_putchar('\n');
//		ft_fill_first(t_t[0], map);
//		ft_fill_map(t_t, map);
//		ft_putstr(tminos);
	}
	else
		ft_putstr("error\n");
	return (0);
}
