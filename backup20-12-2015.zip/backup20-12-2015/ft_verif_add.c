/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_verif_add.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishafie <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/11 22:21:01 by ishafie           #+#    #+#             */
/*   Updated: 2015/12/17 21:21:50 by ishafie          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_fillit.h"


int				ft_check_optimal(char *map, t_tetri *t_t, int index, int nt)
{
	return (1);
}

int				ft_check_extend(char *map, t_tetri t_t, int index, int nt)
{
//	if ((index / (t_t[0].l * (t_t[0]. l - 1))) >= 1)
		map = extend_map(map);
	return (1);
}

int				ft_check_free(char *map, t_tetri *t_t, int index, int nt)
{
	int		i;
	int		l_jump;
	char	alpha[27];

	ft_strcpy(alpha, "ABCDEFGHIJKLMNOPQRSTUVWXYZ");
	l_jump = 0;
	i = 0;
	t_t[nt].tc[i++] = 0;
	if (nt >= t_t[0].nb_t)
		return (ft_add_to_map(map, t_t, index + 1, 0));
	if (map[index] == '\0')
		return (0);
	while (i < 4)
	{
		if (map[index + t_t[nt].tc[i]] != '1' || t_t[nt].available == 0)
			return (ft_check_free(map, t_t, index, nt + 1));
		i++;
	}
	i = 0;
	while (i < 4)
	{
		map[index + t_t[nt].tc[i]] = alpha[nt];
		i++;
	}
	t_t[nt].available = 0;
//	if (!(ft_check_optimal(map, t_t, index, nt)))
//		return (0);
	return (1);
}

int				ft_add_to_map(char *map, t_tetri *t_t, int index, int nt)
{
	int		it;

	it = 0;
	if (map[index] == '\0')
		return (1);
	while (map[index] != '1' && map[index] != '\0')
		index++;
//	if (map[index] != '1')
//		return (ft_add_to_map(map, t_t, index, 0));
	if (ft_check_free(map, t_t, index, 0))
		return (ft_add_to_map(map, t_t, index + 1, 0));
/*	if (ft_check_extend(map, t_t, index, nt))
	return (ft_add_to_map(map, t_t, index + 1, 0));*/
	return (1);
}










