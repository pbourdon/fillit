/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_check.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ishafie <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2015/12/07 10:05:49 by ishafie           #+#    #+#             */
/*   Updated: 2015/12/19 23:28:50 by ishafie          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_fillit.h"

int		ft_check_tetriduo(char *s, int i)
{
	if (s[i + 1] == '#')
	{
		if (s[i + 10] == '#' && s[i + 11] == '#')
			return (-1);
	}
	else if (s[i - 1] == '#')
	{
		if (s[i + 10] == '#' && s[i + 9] == '#')
			return (-1);
	}
	else if (s[i + 5] == '#')
	{
		if (s[i + 2] == '#' && s[i + 7] == '#')
			return (-1);
	}
	else if(s[i - 5] == '#')
	{
		if (s[i + 2] == '#' && s[i - 7] == '#')
			return (-1);
	}
	return (0);
}

int		ft_check_tetri(char *s, int index, int *nt)
{
	int		i;
	int		c_d;

	c_d = 0;
	i = (index - 20);
//	if (*nt == 1)
//		i = 0;
	while (i <= index)
	{
		if (s[i] == '#')
		{
			if (s[i + 1] != '#' && s[i - 1] != '#' && s[i + 5] != '#'
				&& s[i - 5] != '#')
				*nt = -1;
			else if (ft_check_tetriduo(s, i) == -1)
				*nt = -1;
			c_d++;
		}
		i++;
	}
	if (c_d != 4)
		*nt = -1;
	return (0);
}
